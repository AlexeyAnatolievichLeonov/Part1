
#include <G4SystemOfUnits.hh>
#include <G4UserStackingAction.hh>
#include "G4ClassificationOfNewTrack.hh"
#include <G4TrackingManager.hh>
#include <G4StackManager.hh>
#include <G4Event.hh>
#include <G4Gamma.hh>
#include <iomanip>

class StackAct : public G4UserStackingAction 
{
 public:
        std::ofstream*f_stack;
//        G4int counterTracks;

	StackAct(std::ofstream&);
	~StackAct();

        virtual G4ClassificationOfNewTrack ClassifyNewTrack(const G4Track*);
        virtual void NewStage();
        virtual void PrepareNewEvent();
};
